# Aedes albopictus (Skuse) > 2026-05-04 11:58pm
https://universe.roboflow.com/honores-kpxn0/aedes-albopictus-skuse

Provided by a Roboflow user
License: CC BY 4.0

