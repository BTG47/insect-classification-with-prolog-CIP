# Coccinella septempunctata Linnae > 2026-05-04 11:55pm
https://universe.roboflow.com/honores-kpxn0/coccinella-septempunctata-linnae

Provided by a Roboflow user
License: CC BY 4.0

