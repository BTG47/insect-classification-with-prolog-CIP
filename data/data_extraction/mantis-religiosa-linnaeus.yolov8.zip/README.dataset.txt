# My First Project > Mantis religiosa Linnaeus
https://universe.roboflow.com/diegos-workspace-qsa5l/my-first-project-fsccw

Provided by a Roboflow user
License: CC BY 4.0

