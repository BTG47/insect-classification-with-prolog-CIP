# Danaus plexippus (Linnaeus) > 2026-04-30 8:53pm
https://universe.roboflow.com/honores-kpxn0/danaus-plexippus-linnaeus

Provided by a Roboflow user
License: CC BY 4.0

